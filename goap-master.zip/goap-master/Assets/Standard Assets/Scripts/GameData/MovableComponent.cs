using UnityEngine;
using System.Collections;

public class MovableComponent : MonoBehaviour
{
	public float moveSpeed = 20; // units per second

	// Use this for initialization
	void Start ()
	{

	}

	// Update is called once per frame
	void Update ()
	{

	}
}

