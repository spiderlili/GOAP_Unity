Goal Oriented Action Planning AI (GOAP)
Creator: Brent Owens sploreg.com @Sploreg


--------
License
--------
As of Sept 20, 2015 the license is now:

MIT https://opensource.org/licenses/MIT


Previous license: CC-BY
